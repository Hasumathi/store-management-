﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Member_Account : System.Web.UI.Page
{
    private object displayName;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["email"].ToString()=="john@gmail.com")
        {
            useraccName.InnerText = "JOHN";
            userEmail.InnerText = "john@gmail.com";
        }
        else if (Session["email"].ToString() == "mark@gmail.com")
        {
            useraccName.InnerText = "MARK";
            userEmail.InnerText = "mark@gmail.com";
        }
    }
}